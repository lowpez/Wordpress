<div id="sidebar" class="col-md-3 hidden-sx">
	<?php dynamic_sidebar( 'primary' ); ?>
</div>