<div class="nav-container full-menu">
    <nav class="bg-dark">
        <?php get_template_part( 'templates/header/inc', 'header-center-no-top' ); ?>
    </nav>
</div>