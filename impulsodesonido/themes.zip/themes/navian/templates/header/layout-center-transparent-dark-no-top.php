<div class="nav-container full-menu">
    <nav class="transparent absolute nav-dark">
        <?php get_template_part( 'templates/header/inc', 'header-center-no-top' ); ?>
    </nav>
</div>