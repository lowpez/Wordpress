<div class="nav-container full-menu">
    <nav>
        <?php get_template_part( 'templates/header/inc', 'header-center' ); ?>
    </nav>
</div>