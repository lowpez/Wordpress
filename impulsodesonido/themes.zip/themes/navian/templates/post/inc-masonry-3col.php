<div class="col-sm-4 post-wrap masonry-item mb48 overflow-visible">
    <?php get_template_part( 'templates/post/inc', 'content-boxed-masonry' ); ?>
</div>