<div class="col-sm-4 col-xs-12 mb32 mb-xs-24">
    <?php get_template_part( 'templates/post/inc', 'content-boxed' ); ?>
</div>