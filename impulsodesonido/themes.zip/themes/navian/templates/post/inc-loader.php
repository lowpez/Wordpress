<div class="row masonry-loader">
    <div class="col-sm-12 text-center">
        <div class="spinner"></div>
    </div>
</div>