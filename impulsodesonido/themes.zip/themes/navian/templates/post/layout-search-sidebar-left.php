<?php
if (is_active_sidebar( 'primary' )) {
    $page_class = 'col-md-9 mb-xs-24';
    $page_id = 'main-content';
    $post_class = 'p0 sidebar-left';
} else {
    $page_class = 'xs-container';
    $page_id = 'main-content';
    $post_class = 'p0';
}
?>
<section class="<?php echo esc_attr($post_class); ?>">
    <div class="container">
        <div class="row">
            <?php 
            if (is_active_sidebar( 'primary' )) {
                get_sidebar('primary'); 
            }
            ?>
            <div id="<?php echo esc_attr($page_id); ?>" class="<?php echo esc_attr($page_class); ?>">
            	<?php 
        		if ( have_posts() ) : 
                    while ( have_posts() ) : the_post();
            			get_template_part( 'templates/post/content', 'search' );
            		endwhile;
        		else :
        			get_template_part( 'templates/post/content', 'none' );
        		endif;
        		echo function_exists('navian_pagination') ? navian_pagination() : posts_nav_link();
            	?>
            </div>
        </div>
    </div>
</section>