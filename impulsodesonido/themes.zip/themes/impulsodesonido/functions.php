<?php
if( !function_exists( 'navian_child_enqueue_styles' ) ) {
	function navian_child_enqueue_styles() {
	    $parent_style = 'navian-style';
	    wp_enqueue_style( $parent_style, get_template_directory_uri() . '/style.css', 
	    	array( 'navian-libs', 'navian-theme-styles' ) 
	    );
	    wp_enqueue_style( 'navian-child-style', get_stylesheet_directory_uri() . '/style.css',
	        array( $parent_style )
	    );
	}
	add_action( 'wp_enqueue_scripts', 'navian_child_enqueue_styles' );
}

if( !function_exists( 'navian_child_language_setup' ) ) {
	function navian_child_language_setup() {
		load_child_theme_textdomain( 'navian', get_stylesheet_directory() . '/languages' );
	}
	add_action( 'after_setup_theme', 'navian_child_language_setup' );
}

/* Custom script with no dependencies, enqueued in the footer */
/*add_action('wp_enqueue_scripts', 'impulso_enqueue_custom_js');
function impulso_enqueue_custom_js() {
    wp_enqueue_script('custom', get_stylesheet_directory_uri().'/assets/js/js.js', 
    array(), false, true);
}*/