<div class="col-sm-3 col-xs-12 post-wrap masonry-item masonry-boxed mb40 overflow-visible">
    <?php get_template_part( 'templates/post/inc', 'content-boxed-masonry' ); ?>
</div>