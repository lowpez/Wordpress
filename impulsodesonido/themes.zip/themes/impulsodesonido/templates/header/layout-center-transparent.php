<div class="nav-container full-menu">
    <nav class="transparent absolute">
    	<?php get_template_part( 'templates/header/inc', 'header-center' ); ?>
    </nav>
</div>