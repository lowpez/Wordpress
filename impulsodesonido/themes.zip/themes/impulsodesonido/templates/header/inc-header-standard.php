<?php
get_template_part( 'templates/header/inc', 'top' );
get_template_part( 'templates/header/inc', 'header-standard-no-top' );